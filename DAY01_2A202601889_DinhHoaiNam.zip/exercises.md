# K3 — Ngày 1: Bài Tập & Phản Ánh
## Khám Phá LLM API | Phiếu Thực Hành

**Thời lượng:** 9h00–13h00
**Cách làm:** Trả lời từng câu ngay sau khi hoàn thành block tương ứng —
đừng để dồn hết về cuối buổi. Thay dòng `*Câu trả lời của bạn*` bằng câu
trả lời thật (chấm tự động sẽ đếm số câu đã trả lời).

---

## Block 1 — API Cơ Bản (trả lời sau Checkpoint 1)

### Câu 1.1 — Độ nhạy của temperature
Gọi `call_openai` với temperature 0.0, 0.5, 1.0 và 1.5 dùng prompt
**"Hãy kể cho tôi một sự thật thú vị về Việt Nam."**

**Bạn nhận thấy quy luật gì qua bốn phản hồi?** (2–3 câu)
> khi temperature = 0.0, phản hồi có tính nhất quán cao nhất, logic và ngắn gọn, độ sáng tạo thấp. Khi tăng temperature lên 0.5 - 1.0, câu trả lời trở nên đa dạng về mặt từ ngữ. Nếu lên mức 1.5, phản hồi xuất hiện các cấu trúc từ ngữ lạ, ngẫu nhiên cao có thể bị hallucination

### Câu 1.2 — Chọn temperature cho sản phẩm
**Bạn sẽ đặt temperature bao nhiêu cho chatbot hỗ trợ khách hàng, và tại sao?**
> mình sẽ đặt temperature từ 0.1 đến 0.3. Lý do là chatbot hỗ trợ khách hàng đòi hỏi sự chính xác cao, có thể coi gần như tuyệt đối, trung thực với thông tin dịch vụ/sản phẩm và tính nhất quán cao, tránh việc mô hình tự bịa ra thông tin sai sự thật hoặc trả lời không đúng quy chuẩn.

### Câu 1.3 — Đánh đổi chi phí
Kịch bản: 10.000 người dùng hoạt động mỗi ngày, mỗi người gọi API 3 lần,
mỗi lần trung bình ~350 token đầu ra.

**Ước tính GPT-4o đắt hơn GPT-4o-mini bao nhiêu lần cho workload này? Nêu một
trường hợp GPT-4o xứng đáng với chi phí và một trường hợp nên dùng mini:**
> Ước tính GPT-4o đắt hơn GPT-4o-mini khoảng hơn 10 - 15 lần. GPT-4o xứng đáng chi phí cho các bài toán phân tích hợp đồng pháp lý phức tạp hoặc code. Ngược lại, GPT-4o-mini nên được áp dụng cho các tác vụ phổ thông như tóm tắt văn bản ngắn, phân loại cảm xúc phản hồi hoặc chát tự động cơ bản với khách hàng.

---

## Block 2 — System Prompt & Token (trả lời sau Checkpoint 2)

### Câu 2.1 — Sức mạnh của persona
Gọi `chat_with_system_prompt` hai lần với cùng câu hỏi
**"Giải thích blockchain là gì?"** nhưng hai system prompt khác nhau:
- "Bạn là giáo viên tiểu học, giải thích thật đơn giản cho trẻ 8 tuổi."
- "Bạn là chuyên gia tài chính, trả lời chuyên sâu bằng thuật ngữ kỹ thuật."

**Hai phản hồi khác nhau như thế nào (độ dài, từ vựng, ví dụ)? System prompt
ảnh hưởng đến hành vi model ra sao?** (3–4 câu)
> Phản hồi dành cho học sinh 8 tuổi sử dụng hình ảnh so sánh sinh động (như cuốn sổ nhật ký chung cả lớp), câu từ ngắn gọn và từ vựng rất đơn giản. Trong khi đó, phản hồi của chuyên gia tài chính tập trung vào các thuật ngữ chuyên ngành. System prompt đóng vai trò định hình tư duy và tư cách ứng xử, quyết định tông giọng, độ sâu tri thức và cách thức tiếp cận đối tượng của mô hình.

### Câu 2.2 — tiktoken vs đếm từ
Chọn một đoạn văn tiếng Việt ~100 từ. So sánh số token theo `count_tokens`
(tiktoken) với ước lượng `số từ / 0.75` mà Part 1 đã dùng.

**Hai con số chênh nhau bao nhiêu phần trăm? Vì sao tiếng Việt thường tốn
nhiều token hơn tiếng Anh cùng độ dài?**
> Thực tế số token theo tiktoken thường nhiều hơn ước lượng (số từ / 0.75) từ 30% đến 50%. Lý do là các bộ mã hóa khác với tiếng anh, ví dụ như Unicode để hỗ trợ tiếng việt có dấu về mặt xử lí đã khác với tiếng anh, ví dụ chữ a trong tiếng Việt có thể thêm dấu khác token chữ a trong tiếng Anh. Và Tiếng Việt có nhiều từ ghép, âm tiết rời có dấu thanh (dấu sắc, huyền, hỏi, ngã, nặng) dẫn đến các từ thường bị tách thành nhiều token lẻ hơn.

---

## Block 3 — Streaming & Độ Bền (trả lời sau Checkpoint 3)

### Câu 3.1 — Trải nghiệm người dùng với streaming
**Streaming quan trọng nhất trong trường hợp nào, và khi nào thì
non-streaming lại phù hợp hơn?** (1 đoạn văn)
> Streaming quan trọng nhất trong các giao diện tương tác trực tiếp với người dùng như chatbot CLI/Webui hoặc tính năng trợ lý gõ văn bản, giúp giảm thời gian chờ cảm nhận xuống gần như bằng 0. Ngược lại, non-streaming phù hợp hơn cho các tác vụ xử lý ngầm ở backend, gọi API trả về dữ liệu dạng JSON cấu trúc (Structured Outputs), hoặc khi cần kiểm tra/đánh giá toàn bộ câu trả lời trước khi gửi đi.

### Câu 3.2 — Vì sao backoff theo cấp số nhân?
**So với delay cố định (ví dụ luôn chờ 1 giây), exponential backoff có lợi
thế gì khi API bị quá tải? Điều gì xảy ra nếu hàng nghìn client cùng retry
với delay cố định giống nhau?**
> Exponential backoff giúp nới rộng khoảng cách thời gian giữa các lần thử lại, tạo không gian và thời gian cho hệ thống server khôi phục từ tình trạng quá tải. Nếu hàng nghìn client cùng retry với thời gian cố định 1 giây, sẽ dẫn đến hiện tượng request bị dồn dập, làm nghẽn server và khiến hệ thống không thể tự phục hồi.

---

## Block 4 — Mini-Project (trả lời sau Checkpoint 4)

### Câu 4.1 — Thiết kế persona
**Bạn chọn persona gì cho trợ lý của mình? Viết lại system prompt đó và giải
thích 1–2 lựa chọn từ ngữ quan trọng trong prompt (ví dụ: vì sao yêu cầu
"trả lời ngắn gọn", vì sao chỉ định ngôn ngữ...):**
> Persona: "Bạn là trợ giảng thân thiện của khóa AI, trả lời ngắn gọn bằng tiếng Việt." 
> Việc chọn từ "thân thiện" giúp mô hình giữ tông giọng cởi mở, khuyến khích học viên đặt câu hỏi. Yêu cầu "trả lời ngắn gọn" nhằm tối ưu chi phí token và giữ cho cuộc hội thoại đi thẳng vào trọng tâm, còn chỉ định "bằng tiếng Việt" đảm bảo tính nhất quán ngôn ngữ trong toàn bộ phiên hội thoại.

### Câu 4.2 — Hạn chế & cải thiện
**Trợ lý của bạn hiện có hạn chế lớn nhất là gì (ví dụ: history chỉ 3 lượt,
không có bộ nhớ dài hạn, không kiểm duyệt nội dung...)? Đề xuất một cải
thiện cụ thể và mô tả ngắn cách triển khai:**
> Hạn chế lớn nhất hiện tại là lịch sử chỉ giữ 3 lượt gần nhất (6 message), khiến mô hình dễ nhanh quên đi ngữ cảnh quan trọng được thảo luận từ đầu phiên chat. Vì vậy cải thiện đề xuất mình đặt ra: Triển khai tóm tắt hội thoại khi lịch sử vượt quá 6 messages, sử dụng mô hình mini để tóm tắt các đoạn chat cũ thành một đoạn tóm tắt ngắn (summary prompt) và đính kèm vào phần đầu của history thay vì xóa bỏ hoàn toàn. Điều này giúp mô hình luôn ghi nhớ thông tin quan trọng trong toàn bộ phiên chat mà vẫn tối ưu chi phí token.

---

## Danh Sách Kiểm Tra Nộp Bài

- [ ] `python grade.py` — xem điểm tự động, mục tiêu ≥ 75/100
- [ ] Cả 4 checkpoint pytest đều pass
- [ ] Tất cả 9 câu trong file này đã được trả lời
- [ ] Đã copy bài làm vào folder `solution/` và zip theo hướng dẫn README
